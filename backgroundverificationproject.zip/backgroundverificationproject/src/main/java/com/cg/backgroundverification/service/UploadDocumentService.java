package com.cg.backgroundverification.service;

import java.util.List;
import java.util.Optional;

import com.cg.backgroundverification.dto.UploadDocumentDto;



public interface UploadDocumentService {
	
	  public Optional<UploadDocumentDto> getUploadDoc(int uploadDocId);
	 
	  public List<UploadDocumentDto> getAllUploadDetails();
	 
	  public void addUploadDocument(UploadDocumentDto uploadDoc);
	

}
