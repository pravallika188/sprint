package com.cg.backgroundverification.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.backgroundverification.dto.DocumentDto;
import com.cg.backgroundverification.dto.LoginDto;
import com.cg.backgroundverification.dto.UploadDocumentDto;
import com.cg.backgroundverification.serviceimpl.DocumentServiceImpl;
import com.cg.backgroundverification.serviceimpl.LoginServiceImpl;
import com.cg.backgroundverification.serviceimpl.UploadDocumentServiceImpl;




@RestController
public class BackGroundVerificationController {
	@Autowired
	LoginServiceImpl loginService;
	public void setLoginServiceImpl(LoginServiceImpl loginService){ this.loginService=loginService; }
	@Autowired
	UploadDocumentServiceImpl uploadService;
	public void setUploadDocumentService(UploadDocumentServiceImpl uploadService) { this.uploadService=uploadService; }
	@Autowired
	DocumentServiceImpl documentService;
	public void setDocumentService(DocumentServiceImpl documentService) { this.documentService=documentService; }
	
	
	@GetMapping("login/{empid}/{password}")
	public void login(@PathVariable int empid,@PathVariable String password)
	{
		System.out.println(empid);
		System.out.println(password);		  
	    int i=0;
   	List <LoginDto> login=loginService.getLogin();
	   for(LoginDto login1:login)
	   {
		    if(login1.getEmpId()==empid && login1.getPassword().equals(password))
   		       {System.out.println("userfound");
   		       i=2;
   		       if(login1.getRoleId()==401)
   		          {
   		    	   System.out.println("Officer");
   		           }
   		     else {
   		    	 System.out.println("Employee");
   		          }
   		        }
	        
	    }
	      if(i==0)
	      System.out.println("User not found");                                       
	}
	
    @GetMapping(value="/getUploadDocument/{uploadDocId}",produces="application/json")
    public ResponseEntity<Optional< UploadDocumentDto>> getUploadDoc(@PathVariable int uploadDocId)
    {
    	Optional<UploadDocumentDto> uploadDoc =uploadService.getUploadDoc(uploadDocId);
    	if(uploadDoc.isPresent())
    		return new ResponseEntity<Optional<UploadDocumentDto>>(uploadDoc,HttpStatus.OK);
    	 return new ResponseEntity<Optional<UploadDocumentDto>>(uploadDoc,HttpStatus.NOT_FOUND);
    	
  
    }
    
   /*  @PostMapping(value="/addUploadDocument")
    public String addBookingDetails(@RequestBody()UploadDocumentDto uploadDocument)
    {
   	 for(DocumentDto d : uploadDocument.getDocument())
   		 documentService.addDocument(d);
   	     uploadService.addUploadDocument(uploadDocument);
   	     return "Documents stored";
    }*/
    @GetMapping(value="/getAllUploadDocs",produces="application/json")
    public List<UploadDocumentDto> getAllUploadDetails()
    {
   	 return uploadService.getAllUploadDetails();
    }
    
    @PostMapping(value="/uploadDocument",consumes="application/json")
    public ResponseEntity<String> uploadDocument(@RequestBody() UploadDocumentDto uploadDoc)
    {
    	try {
    	for(DocumentDto d : uploadDoc.getDocument())
      		 documentService.addDocument(d);
      	     uploadService.addUploadDocument(uploadDoc);
      	     return new ResponseEntity<String>("Document Uploaded",HttpStatus.OK);
    	}
      	catch(Exception ex)
      	{
      		return new ResponseEntity<String>(ex.getMessage()+" Insertion Failed",HttpStatus.BAD_REQUEST);	
      	}
    }
   
    
    
    /*  
        @PostMapping(value="/addUser",consumes="application/json")
      public ResponseEntity<String> addUserDetails(@RequestBody() User user)
      {
    	  try
    	  {
    	      userService.insertUser(user);
    	      return new ResponseEntity<String>("User Added",HttpStatus.OK);
    	  }
    	  catch(Exception ex)
    	  {
    	    	return new ResponseEntity<String>(ex.getMessage()+" Insertion Failed",HttpStatus.BAD_REQUEST);
    	  } 
      }
      
      
 *  @GetMapping(value="/getUser/{userId}",produces="application/json")
      public ResponseEntity<Optional<User>> getUserDetails(@PathVariable String userId)
      {
    	  Optional<User> user =  userService.getUser(userId);
    	  if(user.isPresent())
    		  return new ResponseEntity<Optional<User>>(user,HttpStatus.OK);
    	  return new ResponseEntity<Optional<User>>(user,HttpStatus.NOT_FOUND);
      }
 * 
 */
	
}
