package com.cg.backgroundverification.service;

import java.util.List;

import com.cg.backgroundverification.dto.LoginDto;

public interface LoginService {
	public List<LoginDto> getLogin();
}
