package com.cg.backgroundverification.service;

import java.util.List;
import java.util.Optional;

import com.cg.backgroundverification.dto.DocumentDto;



public interface DocumentService {
	
      public Optional<DocumentDto>  getDoc(int docId);
	 
	  public List<DocumentDto> getAllDocumentDetails();
	 
	  public void addDocument(DocumentDto doc);

}
