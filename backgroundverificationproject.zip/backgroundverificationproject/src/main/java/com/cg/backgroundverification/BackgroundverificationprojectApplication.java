package com.cg.backgroundverification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackgroundverificationprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackgroundverificationprojectApplication.class, args);
	}

}
