package com.cg.backgroundverification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackgroundverificationprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
